template "Boot Sector exFAT"

description "To be applied to sector 0 of exFAT volume"
applies_to disk
sector-aligned

requires 0x03 "45 58 46 41 54" // ="EXFAT" at offset 3
requires 0x1FE "55 AA"

begin
	read-only hex 3 "JMP instruction"
	char[8]	"OEM"

	move 53	// skip zeros

	section "Volume Information"
	int64 "Sectors preceding partition"
	int64 "Partition size in sectors"
	uint32 "First FAT start sector"
	uint32 "Size of FAT in sectors"
	uint32 "Bitmap start sector"
	uint32 "Cluster count"
	uint32 "Root dir. start cluster"
	hexadecimal uint32 "Volume serial number"
	hex 2 "exFAT version"
	binary "Volume flags"
	uint8 "Active FAT number (0-based)"
	uint8 "Bytes per sector (2^x)"
	uint8 "Sectors per cluster (2^x)"
	uint8 "FAT count"
	hex 1 "BIOS drive type (HD = 0x8*)"
	uint8 "Percent space used"
	endsection

	move 7
	read-only hex 48 "Boot code"
	move 88	// skip zeros
	char[72] "Boot messages"
	read-only hex 118 "Binary zeros"
	read-only hex 61 "Binary ones"
	read-only hex 3 "Unidentified"

	endsection

	goto 0x1FE
	read-only hex 2 "Signature (0x55 0xAA)"
end